#include <iostream>

using namespace std;

const int ascii_size = 255;

class trienode {
public:
    trienode* children[ascii_size];
    bool flag;

    trienode() {
        flag = false;
        for (int i = 0; i < ascii_size; i++) {
            children[i] = nullptr;
        }
    }

    void insert(string word, int depth = 0) {
        if (depth == word.length()) {
            flag = true;
            return;
        }

        int index = word[depth];
        if (children[index] == nullptr) {
            children[index] = new trienode();
        }
        children[index]->insert(word, depth + 1);
    }

    bool search(string word, int depth = 0) {
        if (depth == word.length()) {
            return flag;
        }

        int index = word[depth];
        if (children[index] == nullptr) {
            return false;
        }
        return children[index]->search(word, depth + 1);
    }

    bool* multisearch(string words[], int n) {
        bool* result = new bool[n];
        for (int i = 0; i < n; ++i) {
            result[i] = search(words[i]);
        }
        return result;
    }

    void partialsearch(string prefix, int depth = 0) {
        if (depth == prefix.length()) {
            printallwords(prefix);
            return;
        }

        int index = prefix[depth];
        if (children[index] == nullptr) {
            return;
        }
        children[index]->partialsearch(prefix, depth + 1);
    }

void wordsWithSuffix(string suffix, string current = "") {
    if (flag && current.size() >= suffix.size()) {
        int suffixIndex = suffix.size() - 1;
        int currentSuffixIndex = current.size() - 1;
        bool isSuffix = true;

        // Check if the current string ends with the suffix
        while (suffixIndex >= 0) {
            if (current[currentSuffixIndex] != suffix[suffixIndex]) {
                isSuffix = false;
                break;
            }
            suffixIndex--;
            currentSuffixIndex--;
        }

        // If the current string ends with the suffix, print it
        if (isSuffix) {
            cout << current << endl;
        }
    }

    // Recursively explore the trie
    for (int i = 0; i < ascii_size; ++i) {
        if (children[i] != nullptr) {
            char c = i;
            children[i]->wordsWithSuffix(suffix, current + c);
        }
    }
}




bool remove(string word, int depth = 0) {
    if (depth == word.length()) {
        if (flag) {
            flag = false;
            return isfreenode(); // Indicates whether this node should be deleted
        }
        return false; // Word not found
    }

    int index = word[depth];
    if (children[index] == nullptr) {
        return false; // Word not found
    }

    bool shouldDeleteChild = children[index]->remove(word, depth + 1);

    if (shouldDeleteChild) {
        delete children[index];
        children[index] = nullptr;
    }

    // Return true only if this node should be deleted and it's a leaf node (no children)
    return shouldDeleteChild && isfreenode();
}


    void printallwords(string prefix = "") {
        if (flag) {
            cout << prefix << endl;
        }
        for (int i = 0; i < ascii_size; ++i) {
            if (children[i] != nullptr) {
                char c = i;
                children[i]->printallwords(prefix + c);
            }
        }
    }
    void misspelledSearch(string word, int depth = 0, string current = "") {
            if (depth == word.length()) {
                printallwords(current);
                return;
            }

            int index = word[depth];
            for (int i = 0; i < ascii_size; ++i) {
                if (children[i] != nullptr) {
                    char c = i;
                    // Check for misspelling
                    if (i == index || depth == word.length() - 1) {
                        children[i]->misspelledSearch(word, depth + 1, current + c);
                    } else {
                        children[i]->misspelledSearch(word, depth, current + c);
                    }
                }
            }
    }
    void wildcardSearch(string pattern, int depth = 0, string current = "") {
    if (depth == pattern.length()) {
        printallwords(current);
        return;
    }

    char currentChar = pattern[depth];
    if (currentChar == '*') {
        // Wildcard '*' matches any number of characters
        for (int i = 0; i < ascii_size; ++i) {
            if (children[i] != nullptr) {
                char c = i;
                children[i]->wildcardSearch(pattern, depth + 1, current + c);
            }
        }
    } else {
        // Regular character match
        int index = currentChar;
        if (children[index] != nullptr) {
            children[index]->wildcardSearch(pattern, depth + 1, current + currentChar);
        }
    }
}
void fuzzySearch(string pattern, int depth = 0, string current = "") {
    if (depth == pattern.length()) {
        printallwords(current);
        return;
    }

    char currentChar = pattern[depth];
    if (currentChar == '?') {
        // Wildcard '?' matches any single character
        for (int i = 0; i < ascii_size; ++i) {
            if (children[i] != nullptr) {
                char c = i;
                if (depth == pattern.length() - 1) {
                    // If it's the last character, print all possible words
                    children[i]->printallwords(current + c);
                } else {
                    children[i]->fuzzySearch(pattern, depth + 1, current + c);
                }
            }
        }
    } else {
        // Regular character match
        int index = currentChar;
        if (children[index] != nullptr) {
            children[index]->fuzzySearch(pattern, depth + 1, current + currentChar);
        }
    }
}


  
private:
    bool isfreenode() {
        for (int i = 0; i < ascii_size; ++i) {
            if (children[i] != nullptr) {
                return false;
            }
        }
        return true;
    }


};

int main() {
    trienode root;

    root.insert("apple");
    root.insert("application");
    root.insert("apply");
    root.insert("loading");
    root.insert("interesting");
    root.insert("cat");
    root.insert("coat");
    root.insert("camb");
    root.insert("cable");
    root.insert("bumb");
    root.insert("mcb");
    root.insert("mcob");
    root.insert("mctbc");





    

    cout << "single word search (apple): ";
    if (root.search("apple")) {
        cout << "found" << endl<<endl;
    }
    else {
        cout << "not found" << endl<<endl;
    }

    string words[] = { "apple", "application", "apply" };
    bool* multiresult = root.multisearch(words, 3);
    cout << "multiple words search:" << endl;
    for (int i = 0; i < 3; ++i) {
        cout << words[i] << ": ";
        if (multiresult[i]) {
            cout << "found" << endl<<endl;
        }
        else {
            cout << "not found" << endl<< endl;
        }
    }
    delete[] multiresult;

    string prefix = "appl";
    cout << "partial word search (prefix: " << prefix << "):" << endl<< endl;
    root.partialsearch(prefix);
    cout<< endl;
    string suffix = "ing";
    cout << "words with suffix '" << suffix << "':" << endl<< endl;
    root.wordsWithSuffix(suffix);
    cout<<endl<< endl;

    string misspelled_word = "aple";
    cout << "Misspelled word search (misspelled word: " << misspelled_word << "):" << endl;
    root.misspelledSearch(misspelled_word);

    cout<<endl<<endl;

    string pattern1 = "c*t";
    cout << "Wildcard Search (Pattern: " << pattern1 << "):" << endl;
    root.wildcardSearch(pattern1);
    cout<< endl;
    string pattern2 = "*c*b";
    cout << "Wildcard Search (Pattern: " << pattern2 << "):" << endl;
    root.wildcardSearch(pattern2);
    cout<< endl;
    string pattern3 = "*c*b*";
    cout << "Wildcard Search (Pattern: " << pattern3 << "):" << endl;
    root.wildcardSearch(pattern3);
    cout<< endl;
    string pattern = "c?t";
    cout << "Fuzzy Search (Pattern: " << pattern << "):" << endl;
    root.fuzzySearch(pattern);
    cout<< endl;
    cout<< endl;
    cout << "Removing word 'apple'" << endl;
    root.remove("apple");

    // Perform single word search for "apple" after removal
    cout << "Single word search (apple) after removal: ";
    if (root.search("apple")) {
        cout << "found (should not be found)" << endl;
    } else {
        cout << "not found (as expected)" << endl;
    }

    root.printallwords();

    return 0;
}
